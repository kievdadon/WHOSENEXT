from flask import Flask, render_template, request, jsonify
import requests

app = Flask(__name__)

# Mock data
gigs = [
    {"title": "Assemble Bookshelf", "location": "123 Main St, New York, NY"}
]

@app.route("/admin/gig/0")
def admin_gig():
    return render_template("admin_gig_detail.html", gig=gigs[0])

@app.route("/distance")
def get_distance():
    origin = request.args.get("origin")
    destination = request.args.get("destination")

    # Replace YOUR_API_KEY with actual key in production
    API_KEY = "YOUR_API_KEY"
    url = f"https://maps.googleapis.com/maps/api/distancematrix/json?units=imperial&origins={origin}&destinations={destination}&key={API_KEY}"
    res = requests.get(url).json()

    try:
        distance_text = res["rows"][0]["elements"][0]["distance"]["text"]
        distance_value = res["rows"][0]["elements"][0]["distance"]["value"] / 1609.34  # meters to miles
        mileage_rate = 0.5  # $0.50/mile
        base_pay = 40
        total_payment = round(base_pay + (distance_value * mileage_rate), 2)
        return jsonify({
            "distance_text": distance_text,
            "total_payment": total_payment
        })
    except:
        return jsonify({"error": "Distance calculation failed."}), 500

if __name__ == "__main__":
    app.run(debug=True)
