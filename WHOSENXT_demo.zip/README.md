
# WHOSENXT Demo

## Backend (Flask)
- Navigate to `backend` folder
- Create virtualenv: `python3 -m venv venv`
- Activate: `source venv/bin/activate` (Linux/macOS) or `venv\Scripts\activate` (Windows)
- Install requirements: `pip install -r requirements.txt`
- Run app: `python app.py`

## Frontend (React)
- Navigate to `frontend` folder
- Install dependencies: `npm install`
- Start app: `npm start`
- The React app expects backend at `http://localhost:5000`

## Features
- User signup/login with bcrypt password hashing
- Voice-enabled check-ins using browser SpeechRecognition
- Store item list management demo
