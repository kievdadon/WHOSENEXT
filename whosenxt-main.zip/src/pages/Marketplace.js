import React from "react";

function Marketplace() {
  return (
    <div>
      <h1>WHOSENXT Marketplace 🛒</h1><p>Post and view items here.</p>
    </div>
  );
}

export default Marketplace;