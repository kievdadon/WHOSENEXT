import React from "react";

function Delivery() {
  return (
    <div>
      <h1>WHOSENXT Delivery 🚚</h1><p>Request a delivery.</p>
    </div>
  );
}

export default Delivery;