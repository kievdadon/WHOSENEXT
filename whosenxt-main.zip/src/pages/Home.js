import React from "react";

function Home() {
  return (
    <div>
      <h1>Welcome to WHOSENXT 🏠</h1><p>Select a feature from above to get started.</p>
    </div>
  );
}

export default Home;