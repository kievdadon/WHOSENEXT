import React from "react";

function Family() {
  return (
    <div>
      <h1>WHOSENXT Family 👨‍👩‍👧‍👦</h1><p>Chat and location sharing.</p>
    </div>
  );
}

export default Family;