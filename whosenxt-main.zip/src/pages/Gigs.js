import React from "react";

function Gigs() {
  return (
    <div>
      <h1>WHOSENXT Gigs 🎯</h1><p>Post and browse gigs here.</p>
    </div>
  );
}

export default Gigs;