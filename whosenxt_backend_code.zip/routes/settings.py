from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from models.user_settings import UserSettings
from app import db

settings_bp = Blueprint('settings_bp', __name__)

@settings_bp.route('/update-settings', methods=['POST'])
@jwt_required()
def update_settings():
    user_id = get_jwt_identity()
    data = request.json
    settings = UserSettings.query.filter_by(user_id=user_id).first()

    if not settings:
        settings = UserSettings(user_id=user_id)

    settings.share_location = data.get('share_location', False)
    settings.show_orders_to_family = data.get('show_orders_to_family', True)

    db.session.add(settings)
    db.session.commit()
    return jsonify({'message': 'Settings updated'})