from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required

voice_bp = Blueprint('voice_bp', __name__)

@voice_bp.route('/confirm-command', methods=['POST'])
@jwt_required()
def confirm_command():
    command = request.json.get('command')
    return jsonify({
        'confirmation_needed': True,
        'message': f"You said: '{command}'. Should I continue?"
    })