from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from app import db
from models.gig import Gig

gig_bp = Blueprint('gig_bp', __name__)

@gig_bp.route('/post-gig', methods=['POST'])
@jwt_required()
def post_gig():
    user_id = get_jwt_identity()
    data = request.json
    gig = Gig(
        title=data['title'],
        description=data['description'],
        type=data.get('type', 'standard'),
        location=data['location'],
        customer_id=user_id
    )
    db.session.add(gig)
    db.session.commit()
    return jsonify({'message': 'Gig posted'})

@gig_bp.route('/available-gigs', methods=['GET'])
@jwt_required()
def available_gigs():
    gigs = Gig.query.filter_by(accepted=False).all()
    return jsonify([{
        'id': g.id,
        'title': g.title,
        'type': g.type,
        'priority': g.priority
    } for g in gigs])