from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from app import db
from models.business import Business

business_bp = Blueprint('business_bp', __name__)

@business_bp.route('/create-business', methods=['POST'])
@jwt_required()
def create_business():
    user_id = get_jwt_identity()
    data = request.json
    new_biz = Business(
        owner_id=user_id,
        name=data['name'],
        category=data.get('category'),
    )
    db.session.add(new_biz)
    db.session.commit()
    return jsonify({'message': 'Business created. Awaiting approval.'})

@business_bp.route('/approve-business/<int:biz_id>', methods=['POST'])
@jwt_required()
def approve_business(biz_id):
    biz = Business.query.get(biz_id)
    biz.approved = True
    db.session.commit()
    return jsonify({'message': 'Business approved'})