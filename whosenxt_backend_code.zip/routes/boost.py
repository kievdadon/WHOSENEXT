from flask import Blueprint, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from models.gig import Gig
from app import db
import stripe

stripe.api_key = 'your_secret_key_here'

boost_bp = Blueprint('boost_bp', __name__)

@boost_bp.route('/boost-gig/<int:gig_id>', methods=['POST'])
@jwt_required()
def boost_gig(gig_id):
    user_id = get_jwt_identity()
    gig = Gig.query.get(gig_id)

    if gig.customer_id != user_id:
        return jsonify({'error': 'Unauthorized'}), 403

    session = stripe.checkout.Session.create(
        payment_method_types=['card'],
        line_items=[{
            'price_data': {
                'currency': 'usd',
                'unit_amount': 200,
                'product_data': {'name': 'Boost Gig Visibility'}
            },
            'quantity': 1
        }],
        mode='payment',
        success_url='https://yourdomain.com/success',
        cancel_url='https://yourdomain.com/cancel',
    )

    gig.priority = True
    db.session.commit()

    return jsonify({'checkout_url': session.url})