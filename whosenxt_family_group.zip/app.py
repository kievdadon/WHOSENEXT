from flask import Flask, request, jsonify
import sqlite3
from datetime import datetime

app = Flask(__name__)

# Initialize database
def init_db():
    with sqlite3.connect("family_group.db") as conn:
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user TEXT,
                message TEXT,
                timestamp TEXT
            )
        """)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS locations (
                user TEXT PRIMARY KEY,
                lat REAL,
                lon REAL,
                enabled INTEGER
            )
        """)
init_db()

@app.route('/send-message', methods=['POST'])
def send_message():
    data = request.json
    user = data.get('user')
    message = data.get('message')
    timestamp = datetime.utcnow().isoformat()

    with sqlite3.connect("family_group.db") as conn:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO messages (user, message, timestamp)
            VALUES (?, ?, ?)
        """, (user, message, timestamp))
        conn.commit()

    return jsonify({"message": "Message sent!"})

@app.route('/get-messages', methods=['GET'])
def get_messages():
    with sqlite3.connect("family_group.db") as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT user, message, timestamp FROM messages ORDER BY id DESC LIMIT 50")
        rows = cursor.fetchall()
        return jsonify([{"user": r[0], "message": r[1], "timestamp": r[2]} for r in rows])

@app.route('/update-location', methods=['POST'])
def update_location():
    data = request.json
    user = data.get('user')
    lat = data.get('lat')
    lon = data.get('lon')
    enabled = data.get('enabled')

    with sqlite3.connect("family_group.db") as conn:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO locations (user, lat, lon, enabled)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(user) DO UPDATE SET lat=excluded.lat, lon=excluded.lon, enabled=excluded.enabled
        """, (user, lat, lon, int(enabled)))
        conn.commit()

    return jsonify({"message": "Location updated"})

@app.route('/get-locations', methods=['GET'])
def get_locations():
    with sqlite3.connect("family_group.db") as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT user, lat, lon FROM locations WHERE enabled = 1")
        rows = cursor.fetchall()
        return jsonify([{"user": r[0], "lat": r[1], "lon": r[2]} for r in rows])

if __name__ == '__main__':
    app.run(debug=True)