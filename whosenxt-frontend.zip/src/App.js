import React from "react";
import "./App.css";
import Navbar from "./components/Navbar";

function App() {
  return (
    <div className="App">
      <Navbar />
      <div className="main">
        <h1>Welcome to WHOSENXT 👋</h1>
        <p>Your digital life assistant is live.</p>
        <div className="grid">
          <a href="/marketplace" className="card">Marketplace</a>
          <a href="/gigs" className="card">Gigs</a>
          <a href="/delivery" className="card">Delivery</a>
          <a href="/chat" className="card">Family Chat</a>
        </div>
      </div>
    </div>
  );
}

export default App;