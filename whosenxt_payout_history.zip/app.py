from flask import Flask, jsonify, send_file
import csv
import io
from datetime import datetime

app = Flask(__name__)

# Example hardcoded payout history data
payouts = [
    {"date": "2025-06-21", "type": "Grocery Delivery", "amount": 18.00},
    {"date": "2025-06-20", "type": "Furniture Help", "amount": 47.50},
    {"date": "2025-06-20", "type": "Food Order", "amount": 12.25}
]

@app.route('/payout-history', methods=['GET'])
def get_payout_history():
    return jsonify(payouts)

@app.route('/download-csv', methods=['GET'])
def download_csv():
    si = io.StringIO()
    cw = csv.writer(si)
    cw.writerow(['Date', 'Job Type', 'Amount'])
    for row in payouts:
        cw.writerow([row['date'], row['type'], f"${row['amount']:,.2f}"])
    output = io.BytesIO()
    output.write(si.getvalue().encode('utf-8'))
    output.seek(0)
    return send_file(output, mimetype='text/csv', as_attachment=True, download_name='payout_history.csv')

if __name__ == '__main__':
    app.run(debug=True)