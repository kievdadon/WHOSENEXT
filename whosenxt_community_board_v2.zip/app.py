from flask import Flask, render_template, request, redirect, url_for
from werkzeug.utils import secure_filename
import os
import datetime

app = Flask(__name__)
UPLOAD_FOLDER = 'static/uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# In-memory storage
posts = []

@app.route("/community")
def community_board():
    return render_template("community.html", posts=posts[::-1])

@app.route("/community/post", methods=["GET", "POST"])
def create_post():
    if request.method == "POST":
        title = request.form["title"]
        description = request.form["description"]
        category = request.form["category"]
        location = request.form["location"]
        price = request.form["price"]
        images = []

        # Main image
        main_image = request.files.get("image_main")
        if main_image and main_image.filename:
            filename = secure_filename(main_image.filename)
            path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
            main_image.save(path)
            images.append("/" + path)

        # Verification images
        verify_images = request.files.getlist("verify_images")
        for vimg in verify_images[:3]:
            if vimg and vimg.filename:
                filename = secure_filename(vimg.filename)
                path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
                vimg.save(path)
                images.append("/" + path)

        if len(images) < 4:
            return "Please upload a main image and 3 verification images."

        posts.append({
            "title": title,
            "description": description,
            "price": price,
            "location": location,
            "category": category,
            "images": images,
            "timestamp": datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
        })
        return redirect(url_for("community_board"))

    return render_template("post_form.html")

if __name__ == "__main__":
    app.run(debug=True)
