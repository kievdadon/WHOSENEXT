import stripe
from flask import Flask, request, jsonify

app = Flask(__name__)
stripe.api_key = 'sk_test_your_secret_key_here'  # Replace with your real secret key

@app.route('/create-payment-intent', methods=['POST'])
def create_payment_intent():
    data = request.json
    amount = data.get('amount')  # in cents (e.g., $10 = 1000)
    worker_account_id = data.get('worker_account_id')  # Stripe Connect ID

    try:
        payment_intent = stripe.PaymentIntent.create(
            amount=amount,
            currency='usd',
            payment_method_types=['card'],
            application_fee_amount=int(amount * 0.20),
            transfer_data={
                'destination': worker_account_id,
            }
        )
        return jsonify({'clientSecret': payment_intent['client_secret']})
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@app.route('/create-connect-account', methods=['POST'])
def create_connect_account():
    try:
        account = stripe.Account.create(
            type='express',
            country='US',
            email=request.json.get('email'),
            capabilities={'transfers': {'requested': True}},
        )

        account_link = stripe.AccountLink.create(
            account=account.id,
            refresh_url='https://yourapp.com/reauth',
            return_url='https://yourapp.com/dashboard',
            type='account_onboarding'
        )

        return jsonify({'url': account_link.url})
    except Exception as e:
        return jsonify({'error': str(e)}), 400

if __name__ == '__main__':
    app.run(debug=True)