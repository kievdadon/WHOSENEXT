from flask import Flask, render_template, request, redirect, url_for
from werkzeug.utils import secure_filename
import os
import datetime

app = Flask(__name__)
UPLOAD_FOLDER = 'static/uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# In-memory storage for demo
posts = []

@app.route("/community")
def community_board():
    return render_template("community.html", posts=posts[::-1])

@app.route("/community/post", methods=["GET", "POST"])
def create_post():
    if request.method == "POST":
        title = request.form["title"]
        description = request.form["description"]
        category = request.form["category"]
        image_file = request.files.get("image")
        image_path = ""

        if image_file and image_file.filename:
            filename = secure_filename(image_file.filename)
            image_path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
            image_file.save(image_path)
            image_path = "/" + image_path

        posts.append({
            "title": title,
            "description": description,
            "category": category,
            "image": image_path,
            "timestamp": datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
        })

        return redirect(url_for("community_board"))

    return render_template("post_form.html")

if __name__ == "__main__":
    app.run(debug=True)
