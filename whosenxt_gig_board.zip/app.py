from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

gigs = []
applications = {}

@app.route("/gig/board")
def gig_board():
    return render_template("gig_board.html", gigs=gigs)

@app.route("/gig/post", methods=["GET", "POST"])
def post_gig():
    if request.method == "POST":
        gig = {
            "title": request.form["title"],
            "description": request.form["description"],
            "price": request.form["price"],
            "location": request.form["location"],
            "experience_required": request.form["experience_required"]
        }
        gigs.append(gig)
        return redirect(url_for("gig_board"))
    return render_template("post_gig.html")

@app.route("/gig/apply/<int:gig_id>", methods=["GET", "POST"])
def apply_gig(gig_id):
    if gig_id >= len(gigs):
        return "Gig not found", 404
    if request.method == "POST":
        applicant_name = request.form["applicant_name"]
        applicant_experience = request.form["applicant_experience"]
        if gig_id not in applications:
            applications[gig_id] = []
        applications[gig_id].append({
            "name": applicant_name,
            "experience": applicant_experience
        })
        return redirect(url_for("gig_board"))
    return render_template("apply_gig.html", gig=gigs[gig_id])

if __name__ == "__main__":
    app.run(debug=True)
